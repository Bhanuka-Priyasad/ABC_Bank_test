import mysql.connector
import os
import platform
import maskpass  # importing maskpass library

#get the platform
platform = platform.system()

conn = mysql.connector.connect(
    host="localhost",
    user="root",
    password="redhat",
    database="ABC_Bank"
)
cursor = conn.cursor()


def checkUser(userName, password, count):
    sql = "SELECT password FROM Account WHERE user_name = %s"
    user = (userName, )

    cursor.execute(sql, user)
    result = cursor.fetchall()

    if result == []:
        print("\nInvalid Username or Password...")
        print("Please try again...\n")
        count +=1

        if platform == "Linux":
            os.system('read -p "Press any key to continue..."')
            os.system("clear")
        elif platoform == "Windows":
            os.system('pause')
            os.system("cls")
        main(count)

    else:
        #getting the use entered password
        pw = ""
        for i in result:
            for j in i:
                pw = j 
        #check user entered password and password stored in the database
        if pw == password:
            mainMenu(userName)
            return 1
        else:
            print("\nInvalid Username or Password...")
            print("Please try again...\n")
            count +=1

            if platform == "Linux":
                os.system('read -p "Press any key to continue..."')
                os.system("clear")
            elif platoform == "Windows":
                os.system('pause')
                os.system("cls")

            main(count)


def depositCash(userName):

    if platform == "Linux":
        os.system("clear")
    elif platoform == "Windows":
        os.system("cls")

    print("\n=================================================================")
    print("                         Deposit Cash")
    print("=================================================================\n")
    amount = float(input("Please Enter Amount You Want To Deposit(Rs.): "))
    user = (userName,)
    currentAmount = 0

    sql1 = "SELECT amount FROM Account WHERE user_name = %s"
    cursor.execute(sql1, user)
    result = cursor.fetchall()

    for i in result:
        for j in i:
            currentAmount = j

    newAmount = float(currentAmount) + amount
    new = (newAmount, userName)

    sql2 = "UPDATE Account SET amount = %s WHERE user_name = %s"
    cursor.execute(sql2, new)
    conn.commit()

    if cursor.rowcount != 0:
        print("\nSuccessfull...\n")
        print("Deposit Amount\t: Rs. ", amount)
        print("New Amount\t: Rs. ", newAmount)
        print("\n")

        os.system('read -p "Press any key to continue..." || pause')
        mainMenu(userName)

        return 1
    else:
        print("\nFailed\n")
        os.system('read -p "Press any key to continue..." || pause')
        mainMenu(userName)


def withdrawCash(userName):
    os.system("clear || cls")
    print("\n=================================================================")
    print("                         Withdraw Cash")
    print("=================================================================\n")

    withdrawAmount = float(
        input("Please Enter Amount You Want To Withdraw(Rs.): "))
    user = (userName,)
    currentAmount = 0

    sql1 = "SELECT amount FROM Account WHERE user_name = %s"
    cursor.execute(sql1, user)
    result = cursor.fetchall()

    for i in result:
        for j in i:
            currentAmount = j

    if currentAmount > withdrawAmount:
        newAmount = float(currentAmount) - withdrawAmount
        new = (newAmount, userName)

        sql2 = "UPDATE Account SET amount = %s WHERE user_name = %s"
        cursor.execute(sql2, new)
        conn.commit()

        if cursor.rowcount != 0:
            print("\nTransaction Successful...\n")
            print("Withdraw Amount: Rs. ", withdrawAmount)
            print("Current Balance: Rs. ", newAmount)
            print("\n")

            os.system('read -p "Press any key to continue..." || pause')
            mainMenu(userName)
            return 1
    else:
        print("\nTransaction Failed...")
        print("Not Sufficient Funds...\n")
        os.system('read -p "Press any key to continue..." || pause')
        mainMenu(userName)


def loanCalculator(userName):
    os.system("clear || cls")
    print("\n=================================================================")
    print("                         Loan Calculator")
    print("=================================================================\n")

    loanAmount = float(input("Needed Loan Amount(Rs.): "))
    neededMonths = int(input("Number of Months Needed to Settle The Loan: "))

    monthsIn3Years = 36
    monthsIn5Years = 60
    monthsIn7Years = 84
    loanPeriod = ""
    if neededMonths > 0 :
        if neededMonths <= monthsIn3Years:
            loanPeriod = "3 Years"
        elif neededMonths <= monthsIn5Years:
            loanPeriod = "5 Years"
        elif neededMonths <= monthsIn7Years:
            loanPeriod = "7 Years"
        else:
            loanPeriod = "7 Years+"
    else:
        print("\nPlease Enter Valid a Number...")
        os.system('read -p "Press any key to continue..." || pause')

        loanCalculator(userName)

    if loanPeriod == "3 Years":
        monthlyInterest = loanAmount * ((15/12)/100)
        monthlyRepayment = (loanAmount/neededMonths) + monthlyInterest
        totalAmount = (monthlyRepayment * neededMonths)

        print("\nFor 3 Years Loan...")
        print("Annual Interest Rate\t\t\t: 15%")
        print("Monthly Interest\t\t\t: Rs. ", round(monthlyInterest, 2))
        print("Monthly Repayment\t\t\t: Rs. ", round(monthlyRepayment, 2))
        print("Total Amount Needed To Settle The Loan\t: Rs. ",round(totalAmount, 2))
        print("\n")

        os.system('read -p "Press any key to continue..." || pause')
        mainMenu(userName)

        return 1

    elif loanPeriod == "5 Years":
        monthlyInterest = loanAmount * ((20/12)/100)
        monthlyRepayment = (loanAmount/neededMonths) + monthlyInterest
        totalAmount = (monthlyRepayment * neededMonths)

        print("\nFor 5 Years Loan...")
        print("Annual Interest Rate\t\t\t:  20%")
        print("Monthly Interest\t\t\t: Rs. ", round(monthlyInterest, 2))
        print("Monthly Repayment\t\t\t: Rs. ", round(monthlyRepayment, 2))
        print("Total Amount Needed To Settle The Loan\t: Rs. ",
              round(totalAmount, 2))
        print("\n")

        os.system('read -p "Press any key to continue..." || pause')
        mainMenu(userName)

        return 1

    elif loanPeriod == "7 Years":
        monthlyInterest = loanAmount * ((25/12)/100)
        monthlyRepayment = (loanAmount/neededMonths) + monthlyInterest
        totalAmount = (monthlyRepayment * neededMonths)

        print("\nFor 7 Years Loan...")
        print("Annual Interest Rate\t\t\t:  25%")
        print("Monthly Interest\t\t\t: Rs. ", round(monthlyInterest, 2))
        print("Monthly Repayment\t\t\t: Rs. ", round(monthlyRepayment, 2))
        print("Total Amount Needed To Settle The Loan\t: Rs. ",
              round(totalAmount, 2))
        print("\n")

        os.system('read -p "Press any key to continue..." || pause')
        mainMenu(userName)

        return 1

    elif loanPeriod == "7 Years+":
        monthlyInterest = loanAmount * ((30/12)/100)
        monthlyRepayment = (loanAmount/neededMonths) + monthlyInterest
        totalAmount = (monthlyRepayment * neededMonths)

        print("\nFor 7 Years+ Loan...")
        print("Annual Interest Rate\t\t\t:  30%")
        print("Monthly Interest\t\t\t: Rs. ", round(monthlyInterest, 2))
        print("Monthly Repayment\t\t\t: Rs. ", round(monthlyRepayment, 2))
        print("Total Amount Needed To Settle The Loan\t: Rs. ",
              round(totalAmount, 2))
        print("\n")

        os.system('read -p "Press any key to continue..." || pause')
        mainMenu(userName)

        return 1

    else:
        print("Somthing Went Wrong...")
        print("Please Try Again...")

        os.system('read -p "Press any key to return..." || pause')
        loanCalculator(userName)


def mainMenu(userName):
    os.system("clear || cls")
    print("\n=================================================================")
    print("                         Our Services")
    print("=================================================================\n")
    print("     1. Deposit Cash")
    print("     2. Withdraw Cash")
    print("     3. Loan Calculator")
    print("     4. Exit\n")

    service = input("Please Enter Service Number: ")

    if service == "1":
        depositCash(userName)
    elif service == "2":
        withdrawCash(userName)
    elif service == "3":
        loanCalculator(userName)
    elif service == "4":
        print("\nHave a Nice Day....")
        print("Successfully logged out...\n")
    else:
        print("\nInvalid Service Number...")
        print("Please try again...\n")
        os.system("sleep 2 || pause")
        os.system("clear || cls")
        mainMenu(userName)

    return 1


def main(count):
    print("\n=================================================================")
    print("                         ABC Bank Digital")
    print("=================================================================\n")
    
    if count < 3:
        userName = input("Enter User Name\t: ")
        password = maskpass.advpass("Enter Password\t: ")  # masking the password
        checkUser(userName, password, count)
    else:
        print("\n3 login attempts failed....!!!")
        print("Please Reset Your password or Call 1568...\n")


main(count=0)
