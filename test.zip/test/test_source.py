import pytest
import source   #importing source code


def test_checkUser():
    assert source.checkUser("bhanuka", "1234") == 1


def test_mainMenu():
    assert source.mainMenu("bhanuka") == 1


def test_depositCash():
    assert source.depositCash("bhanuka") == 1


def test_withdrawCash():
    assert source.withdrawCash("bhanuka") == 1


def test_loanCalculator():
    assert source.loanCalculator("bhanuka") == 1




